@echo off
chcp 65001 >nul
title Smart POS - ZAKARIA

echo =========================================
echo    جاري تشغيل نظام الكاشير الذكي...
echo =========================================
taskkill /F /IM node.exe >nul 2>&1
taskkill /F /IM SmartPOS.exe >nul 2>&1

cd /d "%~dp0"

:: فحص هل التطبيق موجود فعلاً أم لا؟
if not exist "SmartPOS.exe" (
    echo.
    echo [خطأ حرج]: ملف SmartPOS.exe غير موجود في المجلد!
    echo قد يكون مكافح الفيروسات قام بحذفه، او انك لم تقم ببنائه.
    echo.
    pause
    exit
)

:: تشغيل السيرفر
start "" "SmartPOS.exe"

:: الانتظار ثانيتين ثم فتح المتصفح كتطبيق احترافي
timeout /t 2 >nul
start chrome --app="http://localhost:3000"
exit